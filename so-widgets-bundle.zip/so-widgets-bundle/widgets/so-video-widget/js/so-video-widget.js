
/* globals jQuery */
jQuery(function ($) {
    $('video.sow-video-widget').mediaelementplayer();
});