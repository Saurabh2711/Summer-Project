smplShortcodeAtts={
	attributes:[
		{
			label:"Style",
			id:"style",
			help:"Select the style of the divider line.", 
			controlType:"select-control", 
			selectValues:['dashed', 'shadow', 'solid']
		}
	],
	defaultContent:"",
	shortcode:"divider"
};
