
	<div class="dwqa-search">
    	<form action="" class="dwqa-search-form">
     		<input class="dwqa-search-input" placeholder="<?php _e( 'Search', 'dwqa' ) ?>">
            <span class="dwqa-search-submit fa fa-search"></span>
            <span class="dwqa-search-loading dwqa-hide"></span>
            <span class="dwqa-search-clear fa fa-times dwqa-hide"></span>
      	</form>
   	</div>