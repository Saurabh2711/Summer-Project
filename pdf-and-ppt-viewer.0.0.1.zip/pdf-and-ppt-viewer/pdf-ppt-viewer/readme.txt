=== PDF and PPT Viewer ===
Contributors: Vladimir Kadalashvili
Donate link: 
Tags: Post, pdf, ppt, medias
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 0.0.1

PDF and PPT Viewer helps you embed PDF documents and Power Point presentations easily. 

== Description ==
PDF and PPT Viewer helps you embed PDF documents and Power Point presentations easily. Does not require Flash to be installed on your computer, pure JavaScript! The plugin makes use of Google Docs undocumented feature.

== Installation ==



1 Upload pdf-ppt-viever folder to the /wp-content/plugins/ directory.

1 Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==
= Why FAQ is required here? =

I don't know, but this should be definitely optional.


== Screenshots ==
1. I have no screenshots of my plugin.



== Changelog ==

= 0.0.1 =
* An initial version