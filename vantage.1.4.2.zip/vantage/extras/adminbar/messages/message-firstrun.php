<?php
$theme = basename( get_template_directory() );
printf( __("Hi! I'm Greg from SiteOrigin. I hope you enjoy using %s. Sign up to <a href='%s' target='_blank'>our newsletter</a> if you'd like more free themes and exclusive offers.", 'vantage'), ucfirst($theme), 'https://siteorigin.com/#newsletter');